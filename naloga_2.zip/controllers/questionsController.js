const Question = require('../models/questionsModel.js'); // Assuming you have a Question model

module.exports = {
    
    list: async (req, res) => {
        try {
        const questions = await Question.find();
        res.render('questions/list', { questions });
        } catch (err) {
        res.status(500).send(err.message);
        }
    },
    
    show: async (req, res) => {
        try {
        const question = await Question.findById(req.params.id);
        res.render('questions/show', { question });
        } catch (err) {
        res.status(404).send('Question not found');
        }
    },

    showCreateForm: function(req, res){
        if (!req.session.userId) {
            return res.redirect('/users/login'); // Require login to post questions
        }
        return res.render('questions/new', {
            title: 'Ask New Question',
            user: req.session.userId // Pass user info if needed
        });
    },


    
    create: async (req, res) => {
        try {
            if (!req.session.userId) {
                return res.redirect('/users/login');
            }
            
            const questionData = {
                title: req.body.title,
                content: req.body.content,
                author: req.session.userId 
            };
            
            const newQuestion = await Question.create(questionData);
            res.redirect(`/questions/${newQuestion._id}`);
        } catch (err) {
            res.status(400).render('questions/new', { 
                title: 'Ask New Question',
                error: err.message 
            });
        }
    },
    

    showEditForm: async (req, res) => {
        try {
        const question = await Question.findById(req.params.id);
        res.render('questions/edit', { question });
        } catch (err) {
        res.status(404).send('Question not found');
        }
    },

    update: async (req, res) => {
        try {
        const updatedQuestion = await Question.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        res.redirect(`/questions/${updatedQuestion._id}`);
        } catch (err) {
        res.status(400).render('questions/edit', { 
            error: err.message,
            question: req.body
        });
        }
    },

    remove: async (req, res) => {
        try {
        await Question.findByIdAndDelete(req.params.id);
        res.redirect('/');
        } catch (err) {
        res.status(500).send(err.message);
        }
    }
};